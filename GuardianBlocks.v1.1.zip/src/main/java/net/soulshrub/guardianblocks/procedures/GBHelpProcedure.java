package net.soulshrub.guardianblocks.procedures;

import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;

public class GBHelpProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof ServerPlayer _player)
			_player.sendSystemMessage(Component.literal("GuardianBlocks Commands:"), false);
		if (entity instanceof ServerPlayer _player)
			_player.sendSystemMessage(Component.literal("gb help = Lists all GuardianBlocks commands, what they do, and how to use them. You just did this one, good job!"), false);
		if (entity instanceof ServerPlayer _player)
			_player.sendSystemMessage(Component.literal("gb add [playerName] = Allows another player access to the Guardian Block you're actively looking at. Player must be online to add. Case sensitive, and player name must be exact."), false);
		if (entity instanceof ServerPlayer _player)
			_player.sendSystemMessage(Component.literal("gb remove [playerName] = Removes a player's access to the Guardian Block you're actively looking at. Case sensitive, and player name must be exact."), false);
		if (entity instanceof ServerPlayer _player)
			_player.sendSystemMessage(Component.literal("gb list = Lists all players who have access to Guardian Block you're actively looking at."), false);
	}
}