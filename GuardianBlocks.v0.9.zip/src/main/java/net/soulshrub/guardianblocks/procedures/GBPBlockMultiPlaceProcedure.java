package net.soulshrub.guardianblocks.procedures;

import net.soulshrub.guardianblocks.init.GuardianblocksModBlocks;

import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.ICancellableEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.GameType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;

import javax.annotation.Nullable;

@EventBusSubscriber
public class GBPBlockMultiPlaceProcedure {
	@SubscribeEvent
	public static void onBlockMultiPlace(BlockEvent.EntityMultiPlaceEvent event) {
		execute(event, event.getLevel(), event.getPos().getX(), event.getPos().getY(), event.getPos().getZ(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double gx = 0;
		double gy = 0;
		double gz = 0;
		double sx = 0;
		double sy = 0;
		double sz = 0;
		boolean guarded = false;
		boolean found = false;
		String active_type = "";
		guarded = false;
		if (entity instanceof Player _plr0 && _plr0.gameMode() == GameType.CREATIVE) {
			guarded = false;
		} else {
			gx = -24;
			for (int _i1 = 0; _i1 < 49; _i1++) {
				gy = -6;
				for (int _i2 = 0; _i2 < 13; _i2++) {
					gz = -24;
					for (int _i3 = 0; _i3 < 49; _i3++) {
						if ((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getBlock() == GuardianblocksModBlocks.GUARDIAN_BLOCK.get()) {
							if ((getPropertyByName((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))), "active_type") instanceof IntegerProperty _getip4
									? (world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getValue(_getip4)
									: -1) > 0) {
								if ((getBlockNBTString(world, BlockPos.containing(x + gx, y + gy, z + gz), "owner_name")).equals(entity.getDisplayName().getString()) != true) {
									if ((getBlockNBTString(world, BlockPos.containing(x + gx, y + gy, z + gz), "allowed")).contains(entity.getDisplayName().getString()) == false) {
										if ((getPropertyByName((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))), "active_type") instanceof IntegerProperty _getip10
												? (world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getValue(_getip10)
												: -1) == 1) {
											if (gx <= 8) {
												if (gx >= -8) {
													if (gy <= 2) {
														if (gy >= -2) {
															if (gz <= 8) {
																if (gz >= -8) {
																	guarded = true;
																}
															}
														}
													}
												}
											}
										} else if ((getPropertyByName((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))), "active_type") instanceof IntegerProperty _getip12
												? (world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getValue(_getip12)
												: -1) == 2) {
											if (gx <= 12) {
												if (gx >= -12) {
													if (gy <= 3) {
														if (gy >= -3) {
															if (gz <= 12) {
																if (gz >= -12) {
																	guarded = true;
																}
															}
														}
													}
												}
											}
										} else if ((getPropertyByName((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))), "active_type") instanceof IntegerProperty _getip14
												? (world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getValue(_getip14)
												: -1) == 3) {
											if (gx <= 16) {
												if (gx >= -16) {
													if (gy <= 4) {
														if (gy >= -4) {
															if (gz <= 16) {
																if (gz >= -16) {
																	guarded = true;
																}
															}
														}
													}
												}
											}
										} else if ((getPropertyByName((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))), "active_type") instanceof IntegerProperty _getip16
												? (world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getValue(_getip16)
												: -1) == 4) {
											if (gx <= 24) {
												if (gx >= -24) {
													if (gy <= 6) {
														if (gy >= -6) {
															if (gz <= 24) {
																if (gz >= -24) {
																	guarded = true;
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
						gz = gz + 1;
					}
					gy = gy + 1;
				}
				gx = gx + 1;
			}
			if (guarded == true) {
				if (event instanceof ICancellableEvent _cancellable) {
					_cancellable.setCanceled(true);
				}
				if (entity instanceof ServerPlayer _player)
					_player.sendSystemMessage(Component.literal("Sorry, you are not able to place blocks here."), true);
			}
		}
	}

	private static Property<?> getPropertyByName(BlockState state, String name) {
		for (Property<?> property : state.getProperties()) {
			if (property.getName().equals(name)) {
				return property;
			}
		}
		return null;
	}

	private static String getBlockNBTString(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return blockEntity.getPersistentData().getStringOr(tag, "");
		return "";
	}
}