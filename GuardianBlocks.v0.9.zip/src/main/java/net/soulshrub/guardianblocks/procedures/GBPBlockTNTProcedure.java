package net.soulshrub.guardianblocks.procedures;

import net.soulshrub.guardianblocks.init.GuardianblocksModBlocks;

import net.neoforged.neoforge.event.level.ExplosionEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.core.BlockPos;

import javax.annotation.Nullable;
import java.util.List;

@EventBusSubscriber
public class GBPBlockTNTProcedure {

    @SubscribeEvent
    public static void onExplosionDetonate(ExplosionEvent.Detonate event) {
        Level world = event.getLevel();
        List<BlockPos> affectedBlocks = event.getAffectedBlocks();
        
        // Remove affected blocks if they fall inside a guarded zone
        affectedBlocks.removeIf(pos -> isGuarded(world, pos.getX(), pos.getY(), pos.getZ()));
    }

    private static boolean isGuarded(LevelAccessor world, int x, int y, int z) {
        double gx = -24;
        for (int _i1 = 0; _i1 < 49; _i1++) {
            double gy = -6;
            for (int _i2 = 0; _i2 < 13; _i2++) {
                double gz = -24;
                for (int _i3 = 0; _i3 < 49; _i3++) {
                    BlockPos currentPos = BlockPos.containing(x + gx, y + gy, z + gz);
                    
                    if (world.getBlockState(currentPos).getBlock() == GuardianblocksModBlocks.GUARDIAN_BLOCK.get()) {
                        int activeType = getPropertyByName(world.getBlockState(currentPos), "active_type") instanceof IntegerProperty _getip
                                ? world.getBlockState(currentPos).getValue(_getip)
                                : -1;

                        if (activeType > 0) {
                            if (activeType == 1 && Math.abs(gx) <= 8 && Math.abs(gy) <= 2 && Math.abs(gz) <= 8) {
                                return true;
                            } else if (activeType == 2 && Math.abs(gx) <= 12 && Math.abs(gy) <= 3 && Math.abs(gz) <= 12) {
                                return true;
                            } else if (activeType == 3 && Math.abs(gx) <= 16 && Math.abs(gy) <= 4 && Math.abs(gz) <= 16) {
                                return true;
                            } else if (activeType == 4 && Math.abs(gx) <= 24 && Math.abs(gy) <= 6 && Math.abs(gz) <= 24) {
                                return true;
                            }
                        }
                    }
                    gz += 1;
                }
                gy += 1;
            }
            gx += 1;
        }
        return false;
    }

    private static Property<?> getPropertyByName(BlockState state, String name) {
        for (Property<?> property : state.getProperties()) {
            if (property.getName().equals(name)) {
                return property;
            }
        }
        return null;
    }

    private static String getBlockNBTString(LevelAccessor world, BlockPos pos, String tag) {
        BlockEntity blockEntity = world.getBlockEntity(pos);
        if (blockEntity != null)
            return blockEntity.getPersistentData().getStringOr(tag, "");
        return "";
    }
}