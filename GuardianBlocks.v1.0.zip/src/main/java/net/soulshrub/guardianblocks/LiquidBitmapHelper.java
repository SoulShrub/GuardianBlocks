/*
 * The code of this mod element is always locked.
 *
 * You can register new events in this class too.
 *
 * If you want to make a plain independent class, create it using
 * Project Browser -> New... and make sure to make the class
 * outside net.soulshrub.guardianblocks as this package is managed by MCreator.
 *
 * If you change workspace package, modid or prefix, you will need
 * to manually adapt this file to these changes or remake it.
 *
 * This class will be added in the mod root package.
*/
package net.soulshrub.guardianblocks;

import net.neoforged.neoforge.event.server.ServerStartingEvent;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.entity.BlockEntity;

@EventBusSubscriber
public class LiquidBitmapHelper {
	public LiquidBitmapHelper() {
	}
	
private static final int WIDTH = 43;
private static final int HEIGHT = 15;
private static final int BIT_COUNT = WIDTH * HEIGHT * WIDTH;
private static final int BYTE_COUNT = (BIT_COUNT + 7) / 8;

private static final String WATER_TAG = "protectingwaterbits";
private static final String LAVA_TAG = "protectinglavabits";

private static int getIndex(double gx, double gy, double gz) {
    int ix = (int) gx;
    int iy = (int) gy;
    int iz = (int) gz;

    if (ix < -21 || ix > 21 ||
        iy < -7 || iy > 7 ||
        iz < -21 || iz > 21) {
        return -1;
    }

    return ((iy + 7) * WIDTH + (ix + 21)) * WIDTH + (iz + 21);
}

public static void recordLiquid(
    LevelAccessor world,
    BlockPos guardianPos,
    double gx, double gy, double gz,
    boolean lava
) {
    int index = getIndex(gx, gy, gz);
    if (index < 0) return;

    BlockEntity blockEntity = world.getBlockEntity(guardianPos);
    if (blockEntity == null) return;

    String tag = lava ? LAVA_TAG : WATER_TAG;
    var data = blockEntity.getPersistentData();

    byte[] bitmap = data.getByteArray(tag).orElse(new byte[0]);

if (bitmap.length == 0) {
    bitmap = new byte[BYTE_COUNT];
} else if (bitmap.length != BYTE_COUNT) {
    return;
}

    bitmap[index >> 3] |= (byte) (1 << (index & 7));

    data.putByteArray(tag, bitmap);
    blockEntity.setChanged();
}

public static boolean isLiquidRecorded(
    LevelAccessor world,
    BlockPos guardianPos,
    double gx, double gy, double gz,
    boolean lava
) {
    int index = getIndex(gx, gy, gz);
    if (index < 0) return false;

    BlockEntity blockEntity = world.getBlockEntity(guardianPos);
    if (blockEntity == null) return false;

    String tag = lava ? LAVA_TAG : WATER_TAG;
    byte[] bitmap = blockEntity.getPersistentData().getByteArray(tag).orElse(new byte[0]);

    if (bitmap.length != BYTE_COUNT) return false;

    return (bitmap[index >> 3] & (1 << (index & 7))) != 0;
}


	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		new LiquidBitmapHelper();
	}

	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
	}

	@EventBusSubscriber
	private static class LiquidBitmapHelperForgeBusEvents {
		@SubscribeEvent
		public static void serverLoad(ServerStartingEvent event) {

		}
	}
}