package net.soulshrub.guardianblocks.procedures;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.GameType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;

public class GuardianBlockBlockIsPlacedByProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double gx = 0;
		double gy = 0;
		double gz = 0;
		if (entity instanceof Player _plr0 && _plr0.gameMode() == GameType.SURVIVAL) {
			if (!world.isClientSide()) {
				BlockPos _bp = BlockPos.containing(x, y, z);
				BlockEntity _blockEntity = world.getBlockEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_blockEntity != null) {
					_blockEntity.getPersistentData().putString("owner_name", (entity.getDisplayName().getString()));
				}
				if (world instanceof Level _level)
					_level.sendBlockUpdated(_bp, _bs, _bs, 3);
			}
		}
		gx = -21;
		for (int _i1 = 0; _i1 < 43; _i1++) {
			gy = -7;
			for (int _i2 = 0; _i2 < 15; _i2++) {
				gz = -21;
				for (int _i3 = 0; _i3 < 43; _i3++) {
					if (!world.isClientSide()) {
    if ((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getBlock() == Blocks.WATER) {
        net.soulshrub.guardianblocks.LiquidBitmapHelper.recordLiquid(world, net.minecraft.core.BlockPos.containing(x, y, z), gx, gy, gz, false);
    }
    if ((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getBlock() == Blocks.LAVA) {
        net.soulshrub.guardianblocks.LiquidBitmapHelper.recordLiquid(world, net.minecraft.core.BlockPos.containing(x, y, z), gx, gy, gz, true);
    }
}
					gz = gz + 1;
				}
				gy = gy + 1;
			}
			gx = gx + 1;
		}
	}
}