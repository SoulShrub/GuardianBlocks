package net.soulshrub.guardianblocks.procedures;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

public class GuardianBlockOnTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		double gx = 0;
		double gy = 0;
		double gz = 0;
		double slx = 0;
		double sly = 0;
		double slz = 0;
		String active_type = "";
		String lapischeck = "";
		String dripstonecheck = "";
		String netherrackcheck = "";
		boolean firedelete = false;
		boolean soulfiredelete = false;
		boolean lavadelete = false;
		boolean waterdelete = false;
		if ((getPropertyByName((world.getBlockState(BlockPos.containing(x, y, z))), "active_type") instanceof IntegerProperty _getip1 ? (world.getBlockState(BlockPos.containing(x, y, z))).getValue(_getip1) : -1) == 1) {
			gx = -5;
			for (int _i1 = 0; _i1 < 11; _i1++) {
				gy = -3;
				for (int _i2 = 0; _i2 < 7; _i2++) {
					gz = -5;
					for (int _i3 = 0; _i3 < 11; _i3++) {
						if ((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getBlock() == Blocks.FIRE) {
							if (((world.getBlockState(BlockPos.containing(x + gx + 0, (y + gy) - 1, z + gz + 0))).getBlock() == Blocks.NETHERRACK) == false) {
								world.setBlock(BlockPos.containing(x + gx, y + gy, z + gz), Blocks.AIR.defaultBlockState(), 3);
							}
						}
						if ((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getBlock() == Blocks.SOUL_FIRE) {
							if (((world.getBlockState(BlockPos.containing(x + gx + 0, (y + gy) - 1, z + gz + 0))).getBlock() == Blocks.SOUL_SAND) == false) {
								if (((world.getBlockState(BlockPos.containing(x + gx + 0, (y + gy) - 1, z + gz + 0))).getBlock() == Blocks.SOUL_SOIL) == false) {
									world.setBlock(BlockPos.containing(x + gx, y + gy, z + gz), Blocks.AIR.defaultBlockState(), 3);
								}
							}
						}
						if ((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getBlock() == Blocks.LAVA) {
							if (((world.getBlockState(BlockPos.containing(x + gx + 0, (y + gy) - 1, z + gz + 0))).getBlock() == Blocks.DRIPSTONE_BLOCK) == false) {
								if (!net.soulshrub.guardianblocks.LiquidBitmapHelper.isLiquidRecorded(world, net.minecraft.core.BlockPos.containing(x, y, z), gx, gy, gz, true) == true) {
									world.setBlock(BlockPos.containing(x + gx, y + gy, z + gz), Blocks.AIR.defaultBlockState(), 3);
								}
							}
						}
						if ((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getBlock() == Blocks.WATER) {
							waterdelete = true;
							slx = -2;
							for (int _i4 = 0; _i4 < 5; _i4++) {
								sly = -2;
								for (int _i5 = 0; _i5 < 5; _i5++) {
									slz = -2;
									for (int _i6 = 0; _i6 < 5; _i6++) {
										if (((world.getBlockState(BlockPos.containing(x + gx + slx, y + gy + sly, z + gz + slz))).getBlock() == Blocks.LAPIS_BLOCK) == true) {
											waterdelete = false;
										}
										slz = slz + 1;
									}
									sly = sly + 1;
								}
								slx = slx + 1;
							}
							if (waterdelete == true) {
								if (!net.soulshrub.guardianblocks.LiquidBitmapHelper.isLiquidRecorded(world, net.minecraft.core.BlockPos.containing(x, y, z), gx, gy, gz, false) == true) {
									world.setBlock(BlockPos.containing(x + gx, y + gy, z + gz), Blocks.AIR.defaultBlockState(), 3);
								}
							}
							waterdelete = true;
						}
						gz = gz + 1;
					}
					gy = gy + 1;
				}
				gx = gx + 1;
			}
		} else if ((getPropertyByName((world.getBlockState(BlockPos.containing(x, y, z))), "active_type") instanceof IntegerProperty _getip25 ? (world.getBlockState(BlockPos.containing(x, y, z))).getValue(_getip25) : -1) == 2) {
			gx = -9;
			for (int _i1 = 0; _i1 < 19; _i1++) {
				gy = -4;
				for (int _i2 = 0; _i2 < 9; _i2++) {
					gz = -9;
					for (int _i3 = 0; _i3 < 19; _i3++) {
						if ((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getBlock() == Blocks.FIRE) {
							if (((world.getBlockState(BlockPos.containing(x + gx + 0, (y + gy) - 1, z + gz + 0))).getBlock() == Blocks.NETHERRACK) == false) {
								world.setBlock(BlockPos.containing(x + gx, y + gy, z + gz), Blocks.AIR.defaultBlockState(), 3);
							}
						}
						if ((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getBlock() == Blocks.SOUL_FIRE) {
							if (((world.getBlockState(BlockPos.containing(x + gx + 0, (y + gy) - 1, z + gz + 0))).getBlock() == Blocks.SOUL_SAND) == false) {
								if (((world.getBlockState(BlockPos.containing(x + gx + 0, (y + gy) - 1, z + gz + 0))).getBlock() == Blocks.SOUL_SOIL) == false) {
									world.setBlock(BlockPos.containing(x + gx, y + gy, z + gz), Blocks.AIR.defaultBlockState(), 3);
								}
							}
						}
						if ((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getBlock() == Blocks.LAVA) {
							if (((world.getBlockState(BlockPos.containing(x + gx + 0, (y + gy) - 1, z + gz + 0))).getBlock() == Blocks.DRIPSTONE_BLOCK) == false) {
								if (!net.soulshrub.guardianblocks.LiquidBitmapHelper.isLiquidRecorded(world, net.minecraft.core.BlockPos.containing(x, y, z), gx, gy, gz, true) == true) {
									world.setBlock(BlockPos.containing(x + gx, y + gy, z + gz), Blocks.AIR.defaultBlockState(), 3);
								}
							}
						}
						if ((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getBlock() == Blocks.WATER) {
							waterdelete = true;
							slx = -2;
							for (int _i4 = 0; _i4 < 5; _i4++) {
								sly = -2;
								for (int _i5 = 0; _i5 < 5; _i5++) {
									slz = -2;
									for (int _i6 = 0; _i6 < 5; _i6++) {
										if (((world.getBlockState(BlockPos.containing(x + gx + slx, y + gy + sly, z + gz + slz))).getBlock() == Blocks.LAPIS_BLOCK) == true) {
											waterdelete = false;
										}
										slz = slz + 1;
									}
									sly = sly + 1;
								}
								slx = slx + 1;
							}
							if (waterdelete == true) {
								if (!net.soulshrub.guardianblocks.LiquidBitmapHelper.isLiquidRecorded(world, net.minecraft.core.BlockPos.containing(x, y, z), gx, gy, gz, false) == true) {
									world.setBlock(BlockPos.containing(x + gx, y + gy, z + gz), Blocks.AIR.defaultBlockState(), 3);
								}
							}
							waterdelete = true;
						}
						gz = gz + 1;
					}
					gy = gy + 1;
				}
				gx = gx + 1;
			}
		} else if ((getPropertyByName((world.getBlockState(BlockPos.containing(x, y, z))), "active_type") instanceof IntegerProperty _getip49 ? (world.getBlockState(BlockPos.containing(x, y, z))).getValue(_getip49) : -1) == 3) {
			gx = -13;
			for (int _i1 = 0; _i1 < 27; _i1++) {
				gy = -5;
				for (int _i2 = 0; _i2 < 11; _i2++) {
					gz = -13;
					for (int _i3 = 0; _i3 < 27; _i3++) {
						if ((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getBlock() == Blocks.FIRE) {
							if (((world.getBlockState(BlockPos.containing(x + gx + 0, (y + gy) - 1, z + gz + 0))).getBlock() == Blocks.NETHERRACK) == false) {
								world.setBlock(BlockPos.containing(x + gx, y + gy, z + gz), Blocks.AIR.defaultBlockState(), 3);
							}
						}
						if ((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getBlock() == Blocks.SOUL_FIRE) {
							if (((world.getBlockState(BlockPos.containing(x + gx + 0, (y + gy) - 1, z + gz + 0))).getBlock() == Blocks.SOUL_SAND) == false) {
								if (((world.getBlockState(BlockPos.containing(x + gx + 0, (y + gy) - 1, z + gz + 0))).getBlock() == Blocks.SOUL_SOIL) == false) {
									world.setBlock(BlockPos.containing(x + gx, y + gy, z + gz), Blocks.AIR.defaultBlockState(), 3);
								}
							}
						}
						if ((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getBlock() == Blocks.LAVA) {
							if (((world.getBlockState(BlockPos.containing(x + gx + 0, (y + gy) - 1, z + gz + 0))).getBlock() == Blocks.DRIPSTONE_BLOCK) == false) {
								if (!net.soulshrub.guardianblocks.LiquidBitmapHelper.isLiquidRecorded(world, net.minecraft.core.BlockPos.containing(x, y, z), gx, gy, gz, true) == true) {
									world.setBlock(BlockPos.containing(x + gx, y + gy, z + gz), Blocks.AIR.defaultBlockState(), 3);
								}
							}
						}
						if ((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getBlock() == Blocks.WATER) {
							waterdelete = true;
							slx = -2;
							for (int _i4 = 0; _i4 < 5; _i4++) {
								sly = -2;
								for (int _i5 = 0; _i5 < 5; _i5++) {
									slz = -2;
									for (int _i6 = 0; _i6 < 5; _i6++) {
										if (((world.getBlockState(BlockPos.containing(x + gx + slx, y + gy + sly, z + gz + slz))).getBlock() == Blocks.LAPIS_BLOCK) == true) {
											waterdelete = false;
										}
										slz = slz + 1;
									}
									sly = sly + 1;
								}
								slx = slx + 1;
							}
							if (waterdelete == true) {
								if (!net.soulshrub.guardianblocks.LiquidBitmapHelper.isLiquidRecorded(world, net.minecraft.core.BlockPos.containing(x, y, z), gx, gy, gz, false) == true) {
									world.setBlock(BlockPos.containing(x + gx, y + gy, z + gz), Blocks.AIR.defaultBlockState(), 3);
								}
							}
							waterdelete = true;
						}
						gz = gz + 1;
					}
					gy = gy + 1;
				}
				gx = gx + 1;
			}
		} else if ((getPropertyByName((world.getBlockState(BlockPos.containing(x, y, z))), "active_type") instanceof IntegerProperty _getip73 ? (world.getBlockState(BlockPos.containing(x, y, z))).getValue(_getip73) : -1) == 4) {
			gx = -21;
			for (int _i1 = 0; _i1 < 43; _i1++) {
				gy = -7;
				for (int _i2 = 0; _i2 < 15; _i2++) {
					gz = -21;
					for (int _i3 = 0; _i3 < 43; _i3++) {
						if ((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getBlock() == Blocks.FIRE) {
							if (((world.getBlockState(BlockPos.containing(x + gx + 0, (y + gy) - 1, z + gz + 0))).getBlock() == Blocks.NETHERRACK) == false) {
								world.setBlock(BlockPos.containing(x + gx, y + gy, z + gz), Blocks.AIR.defaultBlockState(), 3);
							}
						}
						if ((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getBlock() == Blocks.SOUL_FIRE) {
							if (((world.getBlockState(BlockPos.containing(x + gx + 0, (y + gy) - 1, z + gz + 0))).getBlock() == Blocks.SOUL_SAND) == false) {
								if (((world.getBlockState(BlockPos.containing(x + gx + 0, (y + gy) - 1, z + gz + 0))).getBlock() == Blocks.SOUL_SOIL) == false) {
									world.setBlock(BlockPos.containing(x + gx, y + gy, z + gz), Blocks.AIR.defaultBlockState(), 3);
								}
							}
						}
						if ((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getBlock() == Blocks.LAVA) {
							if (((world.getBlockState(BlockPos.containing(x + gx + 0, (y + gy) - 1, z + gz + 0))).getBlock() == Blocks.DRIPSTONE_BLOCK) == false) {
								if (!net.soulshrub.guardianblocks.LiquidBitmapHelper.isLiquidRecorded(world, net.minecraft.core.BlockPos.containing(x, y, z), gx, gy, gz, true) == true) {
									world.setBlock(BlockPos.containing(x + gx, y + gy, z + gz), Blocks.AIR.defaultBlockState(), 3);
								}
							}
						}
						if ((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getBlock() == Blocks.WATER) {
							waterdelete = true;
							slx = -2;
							for (int _i4 = 0; _i4 < 5; _i4++) {
								sly = -2;
								for (int _i5 = 0; _i5 < 5; _i5++) {
									slz = -2;
									for (int _i6 = 0; _i6 < 5; _i6++) {
										if (((world.getBlockState(BlockPos.containing(x + gx + slx, y + gy + sly, z + gz + slz))).getBlock() == Blocks.LAPIS_BLOCK) == true) {
											waterdelete = false;
										}
										slz = slz + 1;
									}
									sly = sly + 1;
								}
								slx = slx + 1;
							}
							if (waterdelete == true) {
								if (!net.soulshrub.guardianblocks.LiquidBitmapHelper.isLiquidRecorded(world, net.minecraft.core.BlockPos.containing(x, y, z), gx, gy, gz, false) == true) {
									world.setBlock(BlockPos.containing(x + gx, y + gy, z + gz), Blocks.AIR.defaultBlockState(), 3);
								}
							}
							waterdelete = true;
						}
						gz = gz + 1;
					}
					gy = gy + 1;
				}
				gx = gx + 1;
			}
		}
	}

	private static Property<?> getPropertyByName(BlockState state, String name) {
		for (Property<?> property : state.getProperties()) {
			if (property.getName().equals(name)) {
				return property;
			}
		}
		return null;
	}
}