package net.soulshrub.guardianblocks.procedures;

import net.soulshrub.guardianblocks.init.GuardianblocksModBlocks;

import net.neoforged.neoforge.transfer.item.ItemResource;
import net.neoforged.neoforge.transfer.ResourceHandler;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.common.extensions.ILevelExtension;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.ICancellableEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.GameType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionHand;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;

import javax.annotation.Nullable;

@EventBusSubscriber
public class GBPBlockEmeraldProcedure {
	@SubscribeEvent
	public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
		if (event.getHand() != InteractionHand.MAIN_HAND)
			return;
		execute(event, event.getLevel(), event.getPos().getX(), event.getPos().getY(), event.getPos().getZ(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double gx = 0;
		double gy = 0;
		double gz = 0;
		double sx = 0;
		double sy = 0;
		double sz = 0;
		boolean guarded = false;
		boolean found = false;
		String active_type = "";
		guarded = false;
		if (entity instanceof Player _plr0 && _plr0.gameMode() == GameType.CREATIVE) {
			guarded = false;
		} else {
			if (getBlockInventorySlotCount(world, BlockPos.containing(x, y, z)) > 0) {
				gx = -20;
				for (int _i1 = 0; _i1 < 49; _i1++) {
					gy = -6;
					for (int _i2 = 0; _i2 < 13; _i2++) {
						gz = -20;
						for (int _i3 = 0; _i3 < 49; _i3++) {
							if ((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getBlock() == GuardianblocksModBlocks.GUARDIAN_BLOCK.get()) {
								if ((getPropertyByName((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))), "active_type") instanceof IntegerProperty _getip5
										? (world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getValue(_getip5)
										: -1) > 0) {
									if ((getBlockNBTString(world, BlockPos.containing(x + gx, y + gy, z + gz), "owner_name")).equals(entity.getDisplayName().getString()) != true) {
										if ((getBlockNBTString(world, BlockPos.containing(x + gx, y + gy, z + gz), "allowed")).contains(entity.getDisplayName().getString()) == false) {
											if ((getPropertyByName((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))), "active_type") instanceof IntegerProperty _getip11
													? (world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getValue(_getip11)
													: -1) == 5) {
												if (gx <= 4) {
													if (gx >= -4) {
														if (gy <= 4) {
															if (gy >= -4) {
																if (gz <= 4) {
																	if (gz >= -4) {
																		guarded = true;
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
							gz = gz + 1;
						}
						gy = gy + 1;
					}
					gx = gx + 1;
				}
				if (guarded == true) {
					if (event instanceof ICancellableEvent _cancellable) {
						_cancellable.setCanceled(true);
					}
					if (entity instanceof ServerPlayer _player)
						_player.sendSystemMessage(Component.literal("Sorry, you are not allowed to open that."), true);
				}
			}
		}
	}

	private static int getBlockInventorySlotCount(LevelAccessor world, BlockPos pos) {
		if (world instanceof ILevelExtension ext) {
			ResourceHandler<ItemResource> itemHandler = ext.getCapability(Capabilities.Item.BLOCK, pos, null);
			if (itemHandler != null)
				return itemHandler.size();
		}
		return 0;
	}

	private static Property<?> getPropertyByName(BlockState state, String name) {
		for (Property<?> property : state.getProperties()) {
			if (property.getName().equals(name)) {
				return property;
			}
		}
		return null;
	}

	private static String getBlockNBTString(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return blockEntity.getPersistentData().getStringOr(tag, "");
		return "";
	}
}