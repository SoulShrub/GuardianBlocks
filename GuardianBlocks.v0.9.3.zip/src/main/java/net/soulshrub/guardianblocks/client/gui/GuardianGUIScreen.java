package net.soulshrub.guardianblocks.client.gui;

import net.soulshrub.guardianblocks.world.inventory.GuardianGUIMenu;
import net.soulshrub.guardianblocks.init.GuardianblocksModScreens;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.Identifier;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import com.mojang.blaze3d.platform.InputConstants;

public class GuardianGUIScreen extends AbstractContainerScreen<GuardianGUIMenu> implements GuardianblocksModScreens.ScreenAccessor {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	private boolean menuStateUpdateActive = false;
	private static final Identifier BACKGROUND = Identifier.parse("guardianblocks:textures/screens/guardian_gui.png");
	private static final Identifier IMAGE_0 = Identifier.parse("guardianblocks:textures/screens/block_of_iron_texture_je3_be3.png");
	private static final Identifier IMAGE_1 = Identifier.parse("guardianblocks:textures/screens/block_of_gold_texture_je5_be3.png");
	private static final Identifier IMAGE_2 = Identifier.parse("guardianblocks:textures/screens/block_of_diamond_texture_je4_be3.png");
	private static final Identifier IMAGE_3 = Identifier.parse("guardianblocks:textures/screens/block_of_netherite_texture_je1_be1.png");
	private static final Identifier IMAGE_4 = Identifier.parse("guardianblocks:textures/screens/block_of_emerald_texture_je4_be3.png");
	private static final Identifier IMAGE_5 = Identifier.parse("guardianblocks:textures/screens/block_of_redstone_texture_je2_be2.png");
	private static final Identifier IMAGE_6 = Identifier.parse("guardianblocks:textures/screens/block_of_lapis_lazuli_texture_je3_be3.png");
	private static final Identifier IMAGE_7 = Identifier.parse("guardianblocks:textures/screens/arrow.png");

	public GuardianGUIScreen(GuardianGUIMenu container, Inventory inventory, Component text) {
		super(container, inventory, text, 176, 129);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		menuStateUpdateActive = false;
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.extractRenderState(guiGraphics, mouseX, mouseY, partialTicks);
	}

	@Override
	public void extractBackground(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.extractBackground(guiGraphics, mouseX, mouseY, partialTicks);
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, BACKGROUND, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, IMAGE_0, this.leftPos + 8, this.topPos + 22, 0, 0, 16, 16, 16, 16);
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, IMAGE_1, this.leftPos + 26, this.topPos + 22, 0, 0, 16, 16, 16, 16);
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, IMAGE_2, this.leftPos + 44, this.topPos + 22, 0, 0, 16, 16, 16, 16);
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, IMAGE_3, this.leftPos + 62, this.topPos + 22, 0, 0, 16, 16, 16, 16);
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, IMAGE_4, this.leftPos + 80, this.topPos + 22, 0, 0, 16, 16, 16, 16);
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, IMAGE_5, this.leftPos + 98, this.topPos + 22, 0, 0, 16, 16, 16, 16);
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, IMAGE_6, this.leftPos + 116, this.topPos + 22, 0, 0, 16, 16, 16, 16);
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, IMAGE_7, this.leftPos + 134, this.topPos + 22, 0, 0, 16, 16, 16, 16);
	}

	@Override
	public boolean keyPressed(KeyEvent event) {
		int key = InputConstants.getKey(event).getValue();
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(event);
	}

	@Override
	protected void extractLabels(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY) {
		guiGraphics.text(this.font, Component.translatable("gui.guardianblocks.guardian_gui.label_insert_block"), 6, 6, -12829636, false);
	}

	@Override
	public void init() {
		super.init();
	}
}