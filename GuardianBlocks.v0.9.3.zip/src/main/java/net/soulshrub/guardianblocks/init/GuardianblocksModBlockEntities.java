/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.soulshrub.guardianblocks.init;

import net.soulshrub.guardianblocks.block.entity.GuardianBlockBlockEntity;
import net.soulshrub.guardianblocks.GuardianblocksMod;

import net.neoforged.neoforge.transfer.item.WorldlyContainerWrapper;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.Block;
import net.minecraft.core.registries.BuiltInRegistries;

@EventBusSubscriber
public class GuardianblocksModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(BuiltInRegistries.BLOCK_ENTITY_TYPE, GuardianblocksMod.MODID);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GuardianBlockBlockEntity>> GUARDIAN_BLOCK = register("guardian_block", GuardianblocksModBlocks.GUARDIAN_BLOCK, GuardianBlockBlockEntity::new);

	// Start of user code block custom block entities
	// End of user code block custom block entities
	private static <T extends BlockEntity> DeferredHolder<BlockEntityType<?>, BlockEntityType<T>> register(String registryname, DeferredHolder<Block, Block> block, BlockEntityType.BlockEntitySupplier<T> supplier) {
		return REGISTRY.register(registryname, () -> new BlockEntityType(supplier, block.get()));
	}

	@SubscribeEvent
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		event.registerBlockEntity(Capabilities.Item.BLOCK, GUARDIAN_BLOCK.get(), WorldlyContainerWrapper::new);
	}
}