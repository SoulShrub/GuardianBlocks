/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.soulshrub.guardianblocks.init;

import net.soulshrub.guardianblocks.GuardianblocksMod;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import java.util.function.Function;

public class GuardianblocksModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(GuardianblocksMod.MODID);
	public static final DeferredItem<Item> GUARDIAN_BLOCK;
	static {
		GUARDIAN_BLOCK = block(GuardianblocksModBlocks.GUARDIAN_BLOCK, new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON));
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, Item.Properties::new);
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), () -> properties);
	}
}