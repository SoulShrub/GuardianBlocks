/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.soulshrub.guardianblocks.init;

import net.soulshrub.guardianblocks.client.gui.GuardianGUIScreen;

import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

@EventBusSubscriber(Dist.CLIENT)
public class GuardianblocksModScreens {
	@SubscribeEvent
	public static void clientLoad(RegisterMenuScreensEvent event) {
		event.register(GuardianblocksModMenus.GUARDIAN_GUI.get(), GuardianGUIScreen::new);
	}

	public interface ScreenAccessor {
		void updateMenuState(int elementType, String name, Object elementState);
	}
}