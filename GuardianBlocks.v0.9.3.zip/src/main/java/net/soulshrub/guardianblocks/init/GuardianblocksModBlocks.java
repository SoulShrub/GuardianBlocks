/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.soulshrub.guardianblocks.init;

import net.soulshrub.guardianblocks.block.GuardianBlockBlock;
import net.soulshrub.guardianblocks.GuardianblocksMod;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import java.util.function.Function;

public class GuardianblocksModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(GuardianblocksMod.MODID);
	public static final DeferredBlock<Block> GUARDIAN_BLOCK;
	static {
		GUARDIAN_BLOCK = register("guardian_block", GuardianBlockBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}