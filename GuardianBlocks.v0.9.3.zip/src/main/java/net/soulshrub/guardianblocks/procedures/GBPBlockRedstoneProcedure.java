package net.soulshrub.guardianblocks.procedures;

import net.soulshrub.guardianblocks.init.GuardianblocksModBlocks;

import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.ICancellableEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionHand;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;

import javax.annotation.Nullable;

@EventBusSubscriber
public class GBPBlockRedstoneProcedure {
	@SubscribeEvent
	public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
		if (event.getHand() != InteractionHand.MAIN_HAND)
			return;
		execute(event, event.getLevel(), event.getPos().getX(), event.getPos().getY(), event.getPos().getZ(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
			
		// BYPASS: Allow players in Creative Mode to bypass restrictions immediately
		if (entity instanceof ServerPlayer _player && _player.isCreative()) {
			return;
		}

		double gx = 0;
		double gy = 0;
		double gz = 0;
		boolean guarded = false;
		
		// Check if the block is a redstone component before scanning
		BlockState clickedState = world.getBlockState(BlockPos.containing(x, y, z));
		if (isRedstoneComponent(clickedState)) {
			gx = -20;
			for (int _i1 = 0; _i1 < 41; _i1++) {
				gy = -6;
				for (int _i2 = 0; _i2 < 13; _i2++) {
					gz = -20;
					for (int _i3 = 0; _i3 < 41; _i3++) {
						if ((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getBlock() == GuardianblocksModBlocks.GUARDIAN_BLOCK.get()) {
							if ((getPropertyByName((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))), "active_type") instanceof IntegerProperty _getip3
									? (world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getValue(_getip3)
									: -1) > 0) {
								if ((getBlockNBTString(world, BlockPos.containing(x + gx, y + gy, z + gz), "owner_name")).equals(entity.getDisplayName().getString()) != true) {
									if ((getBlockNBTString(world, BlockPos.containing(x + gx, y + gy, z + gz), "allowed")).contains(entity.getDisplayName().getString()) == false) {
										if ((getPropertyByName((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))), "active_type") instanceof IntegerProperty _getip9
												? (world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getValue(_getip9)
												: -1) == 6) {
											if (gx <= 4 && gx >= -4 && gy <= 4 && gy >= -4 && gz <= 4 && gz >= -4) {
												guarded = true;
											}
										}
									}
								}
							}
						}
						gz = gz + 1;
					}
					gy = gy + 1;
				}
				gx = gx + 1;
			}
			if (guarded == true) {
				if (event instanceof ICancellableEvent _cancellable) {
					_cancellable.setCanceled(true);
				}
				if (entity instanceof ServerPlayer _player)
					_player.sendSystemMessage(Component.literal("Sorry, you are not allowed to interact with that."), true);
			}
		}
	}

	private static boolean isRedstoneComponent(BlockState state) {
		net.minecraft.world.level.block.Block block = state.getBlock();
		return block instanceof net.minecraft.world.level.block.ButtonBlock ||
			   block instanceof net.minecraft.world.level.block.DoorBlock ||
			   block instanceof net.minecraft.world.level.block.TrapDoorBlock ||
			   block == net.minecraft.world.level.block.Blocks.LEVER;
	}

	private static Property<?> getPropertyByName(BlockState state, String name) {
		for (Property<?> property : state.getProperties()) {
			if (property.getName().equals(name)) {
				return property;
			}
		}
		return null;
	}

	private static String getBlockNBTString(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return blockEntity.getPersistentData().getStringOr(tag, "");
		return "";
	}
}