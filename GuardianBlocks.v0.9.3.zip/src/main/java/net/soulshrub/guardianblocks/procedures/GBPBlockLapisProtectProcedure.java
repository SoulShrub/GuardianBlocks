package net.soulshrub.guardianblocks.procedures;

import net.soulshrub.guardianblocks.init.GuardianblocksModBlocks;

import net.neoforged.neoforge.event.entity.player.AttackEntityEvent;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.ICancellableEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.npc.Npc;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.BlockPos;

import javax.annotation.Nullable;

@EventBusSubscriber
public class GBPBlockLapisProtectProcedure {

	// 1. Protect from Player Attacks
	@SubscribeEvent
	public static void onEntityAttacked(AttackEntityEvent event) {
		if (event.getTarget() != null) {
			Entity attacker = event.getEntity();
			if (attacker instanceof ServerPlayer _player && _player.isCreative()) return;
			
			if (event.getTarget() instanceof Animal || event.getTarget() instanceof Npc) {
				execute(event, event.getTarget().level(), event.getTarget().getX(), event.getTarget().getY(), event.getTarget().getZ(), attacker);
			}
		}
	}

	// 2. Protect from Explosions
	@SubscribeEvent
	public static void onEntityHurt(LivingDamageEvent.Pre event) {
		if (event.getEntity() != null) {
			// Check the damage source directly from the event using getSource()
			if (event.getSource().is(net.minecraft.tags.DamageTypeTags.IS_EXPLOSION)) {
				if (event.getEntity() instanceof Animal || event.getEntity() instanceof Npc) {
					execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), null);
				}
			}
		}
	}	
	
	public static void execute(LevelAccessor world, double x, double y, double z, Entity attacker) {
		execute(null, world, x, y, z, attacker);
	}

private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity attacker) {
		double gx = 0;
		double gy = 0;
		double gz = 0;
		boolean guarded = false;
		
		String attackerName = (attacker != null) ? attacker.getDisplayName().getString() : "";
		
		gx = -20;
		for (int _i1 = 0; _i1 < 41; _i1++) {
			gy = -6;
			for (int _i2 = 0; _i2 < 13; _i2++) {
				gz = -20;
				for (int _i3 = 0; _i3 < 41; _i3++) {
					if ((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getBlock() == GuardianblocksModBlocks.GUARDIAN_BLOCK.get()) {
						if ((getPropertyByName((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))), "active_type") instanceof IntegerProperty _getip3
								? (world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getValue(_getip3)
								: -1) > 0) {
							
							String owner = getBlockNBTString(world, BlockPos.containing(x + gx, y + gy, z + gz), "owner_name");
							String allowed = getBlockNBTString(world, BlockPos.containing(x + gx, y + gy, z + gz), "allowed");
							
							// If there is no attacker (like an explosion), or if the attacker is unauthorized
							if (attacker == null || (!owner.equals(attackerName) && !allowed.contains(attackerName))) {
								if ((getPropertyByName((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))), "active_type") instanceof IntegerProperty _getip9
										? (world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getValue(_getip9)
										: -1) == 7) {
									if (gx <= 4 && gx >= -4 && gy <= 4 && gy >= -4 && gz <= 4 && gz >= -4) {
										guarded = true;
									}
								}
							}
						}
					}
					gz = gz + 1;
				}
				gy = gy + 1;
			}
			gx = gx + 1;
		}
		
		if (guarded == true) {
			if (event instanceof ICancellableEvent _cancellable) {
				_cancellable.setCanceled(true);
			}
		}
	}
	
	private static Property<?> getPropertyByName(BlockState state, String name) {
		for (Property<?> property : state.getProperties()) {
			if (property.getName().equals(name)) {
				return property;
			}
		}
		return null;
	}

	private static String getBlockNBTString(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return blockEntity.getPersistentData().getStringOr(tag, "");
		return "";
	}
}