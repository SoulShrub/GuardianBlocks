package net.soulshrub.guardianblocks.procedures;

import net.soulshrub.guardianblocks.init.GuardianblocksModBlocks;

import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.ICancellableEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;

import javax.annotation.Nullable;
import java.util.Set;
import java.util.HashSet;
import java.util.Arrays;

@EventBusSubscriber
public class GBPBlockLapisSpawnProcedure {
	
	private static final Set<String> HOSTILE_MOBS = new HashSet<>(Arrays.asList(
		"minecraft:bogged", "minecraft:breeze", "minecraft:cave_spider", "minecraft:creeper", 
		"minecraft:drowned", "minecraft:enderman", "minecraft:guardian", "minecraft:elder_guardian", 
		"minecraft:husk", "minecraft:silverfish", "minecraft:skeleton", "minecraft:slime", 
		"minecraft:spider", "minecraft:stray", "minecraft:warden", "minecraft:witch", 
		"minecraft:zombie", "minecraft:zombie_villager", "minecraft:evoker", "minecraft:pillager", 
		"minecraft:ravager", "minecraft:vex", "minecraft:vindicator", "minecraft:blaze", 
		"minecraft:ghast", "minecraft:hoglin", "minecraft:magma_cube", "minecraft:piglin", 
		"minecraft:piglin_brute", "minecraft:wither_skeleton", "minecraft:zoglin", 
		"minecraft:zombified_piglin", "minecraft:endermite", "minecraft:shulker"
	));

	@SubscribeEvent
	public static void onEntitySpawned(EntityJoinLevelEvent event) {
		execute(event, event.getLevel(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
			
		String entityId = BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType()).toString();
		
		if (HOSTILE_MOBS.contains(entityId)) {
			double gx = 0;
			double gy = 0;
			double gz = 0;
			boolean guarded = false;
			
			gx = -20;
			for (int _i1 = 0; _i1 < 41; _i1++) {
				gy = -6;
				for (int _i2 = 0; _i2 < 13; _i2++) {
					gz = -20;
					for (int _i3 = 0; _i3 < 41; _i3++) {
						if ((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getBlock() == GuardianblocksModBlocks.GUARDIAN_BLOCK.get()) {
							if ((getPropertyByName((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))), "active_type") instanceof IntegerProperty _getip5
									? (world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getValue(_getip5)
									: -1) > 0) {
								if ((getPropertyByName((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))), "active_type") instanceof IntegerProperty _getip11
										? (world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getValue(_getip11)
										: -1) == 7) { // Changed to 7 for Lapis tier
									if (gx <= 4 && gx >= -4 && gy <= 4 && gy >= -4 && gz <= 4 && gz >= -4) {
										guarded = true;
									}
								}
							}
						}
						gz = gz + 1;
					}
					gy = gy + 1;
				}
				gx = gx + 1;
			}
			
			if (guarded == true) {
				if (event instanceof ICancellableEvent _cancellable) {
					_cancellable.setCanceled(true);
				}
			}
		}
	}

	private static Property<?> getPropertyByName(BlockState state, String name) {
		for (Property<?> property : state.getProperties()) {
			if (property.getName().equals(name)) {
				return property;
			}
		}
		return null;
	}

	private static String getBlockNBTString(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return blockEntity.getPersistentData().getStringOr(tag, "");
		return "";
	}
}