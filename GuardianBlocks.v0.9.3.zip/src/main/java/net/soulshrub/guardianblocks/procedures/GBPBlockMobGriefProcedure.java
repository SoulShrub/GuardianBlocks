package net.soulshrub.guardianblocks.procedures;

import net.soulshrub.guardianblocks.init.GuardianblocksModBlocks;

import net.neoforged.neoforge.event.entity.EntityMobGriefingEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;

import javax.annotation.Nullable;

@EventBusSubscriber
public class GBPBlockMobGriefProcedure {
	@SubscribeEvent
	public static void onEntityGrief(EntityMobGriefingEvent event) {
		execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double gx = 0;
		double gy = 0;
		double gz = 0;
		double sx = 0;
		double sy = 0;
		double sz = 0;
		boolean guarded = false;
		boolean found = false;
		String active_type = "";
		guarded = false;
		gx = -20;
		for (int _i1 = 0; _i1 < 41; _i1++) {
			gy = -6;
			for (int _i2 = 0; _i2 < 13; _i2++) {
				gz = -20;
				for (int _i3 = 0; _i3 < 41; _i3++) {
					if ((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getBlock() == GuardianblocksModBlocks.GUARDIAN_BLOCK.get()) {
						if ((getPropertyByName((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))), "active_type") instanceof IntegerProperty _getip3
								? (world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getValue(_getip3)
								: -1) > 0) {
							if ((getBlockNBTString(world, BlockPos.containing(x + gx, y + gy, z + gz), "owner_name")).equals(entity.getDisplayName().getString()) != true) {
								if ((getBlockNBTString(world, BlockPos.containing(x + gx, y + gy, z + gz), "allowed")).contains(entity.getDisplayName().getString()) == false) {
									if ((getPropertyByName((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))), "active_type") instanceof IntegerProperty _getip9
											? (world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getValue(_getip9)
											: -1) == 1) {
										if (gx <= 4) {
											if (gx >= -4) {
												if (gy <= 2) {
													if (gy >= -2) {
														if (gz <= 4) {
															if (gz >= -4) {
																guarded = true;
															}
														}
													}
												}
											}
										}
									} else if ((getPropertyByName((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))), "active_type") instanceof IntegerProperty _getip11
											? (world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getValue(_getip11)
											: -1) == 2) {
										if (gx <= 8) {
											if (gx >= -8) {
												if (gy <= 3) {
													if (gy >= -3) {
														if (gz <= 8) {
															if (gz >= -8) {
																guarded = true;
															}
														}
													}
												}
											}
										}
									} else if ((getPropertyByName((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))), "active_type") instanceof IntegerProperty _getip13
											? (world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getValue(_getip13)
											: -1) == 3) {
										if (gx <= 12) {
											if (gx >= -12) {
												if (gy <= 4) {
													if (gy >= -4) {
														if (gz <= 12) {
															if (gz >= -12) {
																guarded = true;
															}
														}
													}
												}
											}
										}
									} else if ((getPropertyByName((world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))), "active_type") instanceof IntegerProperty _getip15
											? (world.getBlockState(BlockPos.containing(x + gx, y + gy, z + gz))).getValue(_getip15)
											: -1) == 4) {
										if (gx <= 20) {
											if (gx >= -20) {
												if (gy <= 6) {
													if (gy >= -6) {
														if (gz <= 20) {
															if (gz >= -20) {
																guarded = true;
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
					gz = gz + 1;
				}
				gy = gy + 1;
			}
			gx = gx + 1;
		}
		if (guarded == true) {
			if (event instanceof EntityMobGriefingEvent _event)
				_event.setCanGrief(false);
		}
	}

	private static Property<?> getPropertyByName(BlockState state, String name) {
		for (Property<?> property : state.getProperties()) {
			if (property.getName().equals(name)) {
				return property;
			}
		}
		return null;
	}

	private static String getBlockNBTString(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return blockEntity.getPersistentData().getStringOr(tag, "");
		return "";
	}
}